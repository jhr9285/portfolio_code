package com.easyfit.service;

import java.util.List;

import com.easyfit.domain.DateData;
import com.easyfit.domain.ScheduleVO;

public interface ScheduleService {
	public int getRegister(ScheduleVO schedule);
	public int getBefore_schedule_add_search(ScheduleVO schedule);
	public List<ScheduleVO> getList(DateData dateData);
	
	/* 수정, 삭제를 위한 리스트 불러오기 */
	/* 조회하기 */
	public ScheduleVO getGet(int idx);
	
	/* 수정하기 */
	public int getUpdate(ScheduleVO schedule);
	
	/* 삭제하기 */
	public int getRemove(ScheduleVO schedule);
}
